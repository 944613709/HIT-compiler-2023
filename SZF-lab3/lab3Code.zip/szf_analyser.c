#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "szf_analyser.h"
#include "szf.tab.h"

extern Node* syntax_tree;
extern int yyparse();
extern void yyrestart(FILE*);

int handleFunc(const char *funcname, const int *arglist, int ptr);

int handleIntArray(Node *tree, int isAarrayOnLeft);

int handleNegativeNum(Node *tree);

char *handleRelop(const Node *condexp);

void handleWhile(Node *tree);

void handleIfElse(Node *tree);

extern int yylineno;

int globalVarId=1;//全局变量的编号
int globalLabelId=1;//全局标签的编号

FILE* foutput=NULL;

void Error(char type,int line,const char* msg){ 

}

//变量表
char* variableNames[100];    //变量名
int variables[100];          //变量的临时编号（对于数组表示其地址）
int varptr=0;

/**
 * @brief 根据variableNames在变量表里查variables中的变量编号
 * 
 * @param name 根据查询的name
 * @return int 
 */
int getVariableByName(char* name){
    for(int i=0; i < varptr; i++)
        if(strcmp(name,variableNames[i]) == 0)
            return variables[i];
    return 0;
}

/**
 * @brief 就是根据var下标用来返回对应的比如说var下标对应的是3代表着常数2---常数2->#2     变量x->t1这种东西
 * 将可能为临时变量或者常量的编号翻译为字符串
 * 
 * @param var 
 * @param k 
 * @return char* 
 */
char* getTranslate(int var,int k){ 
    static char temp[3][30];
    sprintf(temp[k], "%s%d", (var <= 0 ? "#" : "t"), ((var <= 0) ? -var : var));
    return temp[k];
}

/**
 * @brief 对于非条件的Exp生成计算代码并返回临时变量在符号表中的编号
 * 如果是常数x，则返回-x（此时返回值<=0）
 * @param tree 
 * @param isAarrayOnLeft isAarrayOnLeft=1则表示数组，返回的是数组元素地址
 * @return int 
 */
int CalcExp(Node* tree,int isAarrayOnLeft){
    switch(tree->subtype){
    case 0:     //Exp->ID
        return getVariableByName(tree->child->str_val);//比如扫描到的是a,那么返回对应的t1的1
    case 1:     //Exp->INT
        return -tree->child->int_val;
    case 3:     //Exp->LP EXP RP
        return CalcExp(tree->child->next,0);
    case 4:     //Exp->ID LP RP
    case 5:{    //Exp->ID LP Args RP
        //Args → Exp COMMA Args | Exp
        char* funcname=tree->child->str_val;
        Node* args=tree->child->next->next;
        static int arglist[30];
        int ptr=0;
        if(!args->isTerminal){
            while(1){
                Node* exp=args->child;
                arglist[ptr++]=CalcExp(exp,0);//
                if(args->subtype == 0)  //Args->Exp
                    break;
                args=args->child->next->next;
            }
        }
        //处理函数调用
        return handleFunc(funcname, arglist, ptr);
    }
    case 6:{
        //Exp->Exp LB Exp RB
        //处理int数组
        return handleIntArray(tree, isAarrayOnLeft);
    }
    case 8:{    //Exp->MINUS Exp
        //处理负数
        return handleNegativeNum(tree);
    }
    case 10:    //Exp->Exp STAR Exp
    case 11:    //Exp->Exp DIV Exp
    case 12:    //Exp->Exp PLUS Exp
    case 13:{   //Exp->Exp MINUS Exp
        char op=(tree->subtype == 10) ? '*' : (
                (tree->subtype == 11) ? '/' : (
                (tree->subtype == 12) ? '+' : '-'));
        int a=CalcExp(tree->child,0),b=CalcExp(tree->child->next->next,0);
        int ret=globalVarId++;
        fprintf(foutput,"t%d := %s %c %s\n",ret,getTranslate(a,0),op,getTranslate(b,1));
        return ret;
    }
    case 17:{   //Exp->Exp ASSIGNOP Exp
        int re=CalcExp(tree->child->next->next,0);
        int le=CalcExp(tree->child,1);
        if(tree->child->subtype == 6)   //左边是数组，返回的是地址，解引用赋值
            fprintf(foutput,"*t%d := %s\n",le,getTranslate(re,0));
        else
            fprintf(foutput,"t%d := %s\n",le,getTranslate(re,0));
        return le; 
    }
    default:{
        printf("Error when calc exp\n");
        exit(-1);
    }
    }
}
/**
 * @brief 处理函数调用
 * @param tree
 * @return
 */
int handleNegativeNum(Node *tree) {
    int re=CalcExp(tree->child->next, 0);
    int ret=globalVarId++;
    fprintf(foutput,"t%d := #0 - %s\n",ret,getTranslate(re,0));
    return ret;
}

/**
 * @brief 处理函数调用
 * @param tree
 * @param isAarrayOnLeft
 * @return
 */
int handleIntArray(Node *tree, int isAarrayOnLeft) {//处理int数组
    //比如a[0]=0; ----->
    // t2 := &t1
    // t3 := #0 * #4
    // t3 := t3 + t2
    // *t3 := #0
    //保证一维数组
    char* name=tree->child->child->str_val; //第一个Exp一定是Exp->ID
    int baseaddr=getVariableByName(name);    //数组基地址变量编号,比如根据a查到a[]的数组首地址
    int addr=globalVarId++;
    int index=CalcExp(tree->child->next->next,0);//获取a[2]的2
    fprintf(foutput,"t%d := %s * #4\n",addr,getTranslate(index,0));//偏移地址
    fprintf(foutput,"t%d := t%d + t%d\n",addr,addr,baseaddr);//实际地址
    if(isAarrayOnLeft)
        return addr;    //数组元素为左值，取地址即可，没必要取值
    int ret=globalVarId++;
    fprintf(foutput,"t%d := *t%d\n",ret,addr);  //否则，用在表达式中，取地址处值
    return ret;
}

/**
 * @brief 处理函数调用,处理read与write以及其他函数
 * @param funcname
 * @param arglist
 * @param ptr
 * @return
 */
int handleFunc(const char *funcname, const int *arglist, int ptr) {
    //特殊处理输入输出函数read与write
    //比如n = read();
    if(strcmp(funcname,"read") == 0){
        int ret=globalVarId++;
        fprintf(foutput,"READ t%d\n",ret);
        return ret;
    }
    else if(strcmp(funcname,"write") == 0){
        fprintf(foutput,"WRITE %s\n",getTranslate(arglist[0],0));
        return 0;   //write不参与运算，随便返回点啥
    }
    for(int i=ptr - 1; i >= 0; i--)
        fprintf(foutput,"ARG %s\n",getTranslate(arglist[i],0));
    int ret=globalVarId++;
    fprintf(foutput,"t%d := CALL %s\n",ret,funcname);
    return ret;
}

/**
 * @brief 处理if/while的，比如生成IF t1 > #0 GOTO label1
 * 
 * @param condexp 
 * @param true_label 
 */
void CondExp(Node* condexp,int true_label){
    //处理if/while使用的条件表达式，若真则跳转到指定标签
    //保证条件表达式一定为Exp RELOP Exp或者普通Exp（判断非0）
    if(condexp->subtype == 14){ //Exp->Exp RELOP Exp
        int a=CalcExp(condexp->child,0);
        int b=CalcExp(condexp->child->next->next,0);
        char *rel = handleRelop(condexp);//获取关系运算符
        fprintf(foutput,"IF %s %s %s GOTO label%d\n",getTranslate(a,0),rel,getTranslate(b,1),true_label);
    }
    else{  //普通Exp，先计算然后判断是否非0
        int cond=CalcExp(condexp,0);
        fprintf(foutput,"IF %s != #0 GOTO label%d\n",getTranslate(cond,0),true_label);
    }
}
/**
 * @brief 处理关系运算符
 * @param condexp
 * @return
 */
char *handleRelop(const Node *condexp) {
    char* rel;
    int relop=condexp->child->next->relop;
    switch(relop){
    case RELOP_EQU: rel="=="; break;
    case RELOP_NEQ: rel="!="; break;
    case RELOP_GE:  rel=">="; break;
    case RELOP_LE:  rel="<="; break;
    case RELOP_GT:  rel=">";  break;
    case RELOP_LT:  rel="<";  break;
    }
    return rel;
}
/**
 * @brief 处理生成中间代码
 * @param tree
 */
void Compile(Node* tree){
    //对一般语法树生成中间代码
    if(tree->isTerminal)
        return;
    switch(tree->type)
    {
    case Unterm_ExtDef:{
        //ExtDef → Specifier FunDec CompSt
        //这里仅处理函数定义，并且specifier一定为INT
        Node* fundec=tree->child->next;
        Node* varlist=fundec->child->next->next;
        fprintf(foutput,"FUNCTION %s :\n",fundec->child->str_val);//比如int main（） 输出FUNCTION main :
        if(!varlist->isTerminal){   //varlist不为空
            while(1){
                Node* paramdec=varlist->child;
                int arg=globalVarId++;//方法参数变量编号也得是和gid来管理
                fprintf(foutput,"PARAM t%d\n",arg);//比如说int fact(int n)读取int n --->PARAM t1
                Node* vardec=paramdec->child->next;
                //存入variableNames表
                variableNames[varptr]=vardec->child->str_val;    //假定数组不作为参数，只有ID
                //存入variables表
                variables[varptr++]=arg; //连同名字存入变量表
                if(varlist->subtype == 1)   //VarList->ParamDec
                    break;
                varlist=varlist->child->next->next; //VarList → ParamDec COMMA VarList
            }
        }
        Node* compst=tree->child->next->next;
        Compile(compst);
        return;
    }
    case Unterm_CompSt:{
        Node* deflist=tree->child->next;
        Node* stmtlist=tree->child->next;
        if(!deflist->isTerminal && deflist->type == Unterm_DefList){
            stmtlist=stmtlist->next;
            //处理deflist中的变量定义
            while(deflist != NULL){     //枚举DefList中的每一行Def
                Node* def=deflist->child;
                Node* declist=def->child->next;
                while(1){               //枚举DecList中的每一个Dec（定义的单个变量）
                    Node* dec=declist->child;
                    Node* vardec=dec->child;
                    int var=globalVarId++;      //新分配一个临时变量
                    if(vardec->subtype == 0){   //VarDec->ID
                        //比如说读到int a;就记录把a记录为t1,然后记录到variableNames表中,以后可以拿a找到t1
                        variableNames[varptr]=vardec->child->str_val;
                        variables[varptr++]=var;   
                        if(dec->subtype == 1){  //Dec → VarDec ASSIGNOP Exp
                            //处理赋初值表达式
                            int re=CalcExp(dec->child->next->next,0);
                            fprintf(foutput,"t%d := %s\n",var,getTranslate(re,0));
                        }
                    }else{  //VarDec->VarDec LB INT RB, 假定一定是一维数组
                        int size=vardec->child->next->next->int_val;
                        // DEC x [size] 内存空间申请，大小为4的倍数。
                        // 如果我们需要声明一个长度为10的int类型数组a，则可以写成DEC a 40
                        //如写出DEC t1 92------->t1记录的是a[],数组a的首地址
                        fprintf(foutput,"DEC t%d %d\n",var,size * 4);
                        int addr=globalVarId++;
                        fprintf(foutput,"t%d := &t%d\n",addr,var);
                        //注意：var仅表示这个数组，而addr表示其首地址
                        //以后var这个编号就没用了，用数组的时候直接用表示地址的临时变量addr
                        variableNames[varptr]=vardec->child->child->str_val; //第一个VarDec一定是ID
                        variables[varptr++]=addr;
                    }
                    if(declist->subtype == 0)   //DecList->Dec
                        break;
                    declist=declist->child->next->next; //DecList → Dec COMMA DecList
                }
                deflist=deflist->child->next;
            }
        }
        if(!stmtlist->isTerminal && stmtlist->type == Unterm_StmtList)
            Compile(stmtlist);      //直接递归处理stmtlist
        return;
    }
    case Unterm_Stmt:{
        /*
        Stmt → Exp SEMI | CompSt | RETURN Exp SEMI | IF LP Exp RP Stmt 
                | IF LP Exp RP Stmt ELSE Stmt | WHILE LP Exp RP Stmt
        */
        switch(tree->subtype){
        case 0: //Stmt->Exp SEMI
            CalcExp(tree->child,0); break;
        case 1: //Stmt->CompSt
            Compile(tree->child); break;
        case 2:{//Stmt->RETURN Exp SEMI
            int ret=CalcExp(tree->child->next,0);
            fprintf(foutput,"RETURN %s\n",getTranslate(ret,0));
            break;
        }
        case 3: //IF LP Exp RP Stmt

        //处理if-else思路:
        // if 真  GOTO true_label
        // (若有else 则在这里继续把这个else作为新的一句进行迭代分析)
        //(如果是if-else则把第二个else看做一条语句段,如果是if-else-else....则会把第二个else当做if处理，直到最后一个else当做语句段处理)
        // GOTO end_label
        // LABEL true_label:
        //  真的话要做xxxxx
        // LABEL end_label:
        // 整个if结束后的要做的xxxxx
        case 4:{//IF LP Exp RP Stmt ELSE Stmt
            handleIfElse(tree);//处理if-else
            break;
        }
        //处理while思路：
//         1 LABEL begin_label:
        // 2 [ 计 算 条 件 表 达 式 ]
        // 3 IF [ 条件为真 ] GOTO true_label
        // 4 GOTO end_label
        // 5 LABEL true_label:
        // 6 [ 循环体 ]
        // 7 GOTO begin_label
        // 8 LABEL end_label:
        case 5:{    //WHILE LP Exp RP Stmt
            handleWhile(tree);//处理while
            break;
        }
        }
        return;
    }
    default:{
        for(Node* ptr=tree->child; ptr != NULL; ptr=ptr->next)
            Compile(ptr);
    }
    }
}
/**
 * 处理if-else
 * @param tree
 */
void handleIfElse(Node *tree) {//保证Exp一定是ID或者Exp RELOP Exp这样的简单条件表达式
    int true_label=globalLabelId++;    //True语句体入口
    int end_label=globalLabelId++;     //if后续语句
    Node* condexp=tree->child->next->next;
    CondExp(condexp,true_label);//生成IF t1 > #0 GOTO label1
//如果有else，把else语句体放在前面，这样省跳转
    if(tree->subtype == 4)  //IF LP Exp RP Stmt ELSE Stmt
    {
        //如果有else，再处理一次else
        Compile(tree->child->next->next->next->next->next->next);   //生成else的stmt代码
    }

    fprintf(foutput,"GOTO label%d\n",end_label);    //无论是不是有else，条件不成立时必须跳过true语句块
    fprintf(foutput,"LABEL label%d :\n",true_label);
    Compile(tree->child->next->next->next->next);//处理true_label应该执行的语句
    fprintf(foutput,"LABEL label%d :\n",end_label);//结束时打个end_label要执行的语句
}

/**
 * 处理while语句
 * @param tree
 */
void handleWhile(Node *tree) {
    int begin_label=globalLabelId++;   //循环入口
    int true_label=globalLabelId++;    //循环体入口
    int end_label=globalLabelId++;     //循环后续语句
    fprintf(foutput,"LABEL label%d :\n",begin_label);
    Node* condexp=tree->child->next->next;
    CondExp(condexp,true_label);
    fprintf(foutput,"GOTO label%d\n",end_label);    //结束循环
    fprintf(foutput,"LABEL label%d :\n",true_label);
    Compile(tree->child->next->next->next->next);
    fprintf(foutput,"GOTO label%d\n",begin_label);
    fprintf(foutput,"LABEL label%d :\n",end_label);
}
/**
 * 获取语法树
 * @param filename
 */
void get_syntax_tree(const char* filename){
    syntax_tree=NULL;
    yylineno=1;
    FILE* f=fopen(filename,"r");
    if(f == NULL){
        printf("Error: Cannot open file '%s'\n",filename);
        exit(-1);
    }
    yyrestart(f);
    yyparse();
    fclose(f);
}
/**
 * 主函数
 * @param argc
 * @param argv
 * @return
 */
int main(int argc,char** argv){
    if(argc < 3){
        printf("Error: Too few args.\n");
        return -1;
    }
    get_syntax_tree(argv[1]);
    foutput=fopen(argv[2],"w");
    if(foutput == NULL){
        printf("Cannot open output file\n",argv[2]);
        return -1;
    }
    Compile(syntax_tree);
    fclose(foutput);
    return 0;
}
