/*
    版权声明：此版火炬仅供“相亲相爱一家人”群成员使用
    出于不可抗力之原因，非本群成员没有查看或使用它的任何权利
    否则将永久受到来自我的精神谴责
    此外，绝对禁止以任何理由向其他人转发、出示等
    最终解释权归作者所有
*/

/*
    By ywy_c_asm
    由于lab2需要稍微复杂的字符串和数据结构操作，而我们只能用C语言
    因此我在这用基于(胡乱)动态内存分配的方式实现了简单的字符串/映射表等数据结构
    这样会大大降低编程难度
    这里面malloc的内存区太**多了，我懒得free了，反正输入数据量很小，但是这样不是较好的写法

    此外，除了抽象数据结构，这里还有和lab2密切相关的表示类型的Type和表示函数的Func的数据结构
*/

#ifndef DATASTRUCT

#define DATASTRUCT

#include<string.h>
#include<stdlib.h>
#include<stdio.h>


typedef struct{     //方便操作的字符串类String（模仿C++里的std::string）
    char* str;      //字符串地址，动态分配的内存区
    int length;     //字符串长度
}String;

String GenStr(const char* str){     //构造一个String
    int len=strlen(str);
    String s;
    s.length=len;
    s.str=(char*)malloc(len + 2);
    memcpy(s.str,str,len + 1);
    return s;
}

String GenStrN(int n){      //根据数字构造一个String
    static char buf[30];
    memset(buf,0,sizeof(buf));
    sprintf(buf,"%d",n);
    return GenStr(buf);
}

String GenStrRand(){        //生成一个随机字符串（用于给匿名的struct命名）
    static char buf[30];
    for(int i=0; i < 5; i++)
        buf[i]=rand() % 26 + 'a';
    buf[5]=0;
    return GenStr(buf);
}

String CopyStr(String str){ //字符串拷贝
    return GenStr(str.str);
}

String AddStr(String a,String b){   //字符串拼接
    String c;
    c.length=a.length + b.length;
    c.str=(char*)malloc(a.length + b.length + 2);
    memcpy(c.str,a.str,a.length + 1);
    memcpy(c.str + a.length,b.str,b.length + 1);
    return c;
}

String AddStrR(String a,const char* b){ //字符串拼接
    int lb=strlen(b);
    String c;
    c.length=a.length + lb;
    c.str=(char*)malloc(a.length + lb + 2);
    memcpy(c.str,a.str,a.length + 1);
    memcpy(c.str + a.length,b,lb + 1);
    return c;
}

int EquStr(String a,String b){  //判断两个String是否相等
    if(a.length != b.length)
        return 0;
    return strcmp(a.str,b.str) == 0;
}

typedef struct _hn{         //映射表结点，映射表用于建立一个从String字符串到某种对象的指针的抽象映射
                            //也就是说你给出一个字符串(比如变量/类型/函数名)就可以在里面查找对应的对象
                            //这就是用来实现课上讲的所谓的“符号表”的
                            //在我自己的版本里，我是用真的哈希表实现的
                            //但便于大家学习，反正数据量也不大，这个版本改成了简单的链表，暴力在上面查询
    String str;
    void* value;            //值，可以是任何类型对象的指针（这是抽象数据结构）
    struct _hn* next;
}HashNode;

typedef HashNode** HashMap; //其实就是简单的链表，你其实完全可以用自己的方式实现！

HashMap CreateMap(){        //初始化映射表
    HashMap hm=(HashMap)malloc(sizeof(HashNode*));
    hm[0]=NULL;
    return hm;
}

void* FindMap(HashMap map,String str){  //在这个链表里暴力查找字符串对应的值
    for(HashNode* ptr=map[0]; ptr != NULL; ptr=ptr->next)
        if(EquStr(ptr->str,str))
            return ptr->value;
    return NULL;                        //查找失败
}

void InsertMap(HashMap map,String key,void* value){      //简单链表插入，保证不存在重复key
    HashNode* nd=(HashNode*)malloc(sizeof(HashNode));
    nd->next=map[0];
    nd->str=CopyStr(key);
    nd->value=value;
    map[0]=nd;
}

void RemoveMap(HashMap map,String key){ //删除key为指定字符串的结点
    if(map[0] == NULL)
        return;
    if(EquStr(map[0]->str,key)){
        HashNode* tmp=map[0]->next;
        map[0]=tmp;
        return;
    }
    for(HashNode* ptr=map[0]; ptr->next != NULL; ptr=ptr->next){
        if(EquStr(ptr->next->str,key)){
            HashNode* tmp=ptr->next;
            ptr->next=tmp->next;
            return;
        }
    }
}

#define Type_INT    0
#define Type_FLOAT  1
#define Type_Struct 2
#define Type_Array  3

typedef struct _tp{     //表示一个类型(数值/数组/struct)具体的信息
    int type;
    int size;           //对于array为数组容量，对于struct为成员个数
    struct _tp* arrbase;    //对于array是数组基类型
                            //注意：对于多维数组，Type进行嵌套处理，例如
                            //int[2][3]被视作一个基类型为int[2]的容量为3的一维数组
    struct _tp** list;  //这是一个动态分配的变长数组，仅对struct有效，表示各个成员的类型
    String* names;      //是和list保持一致的变长数组，仅对struct有效，便是各个成员的名称
    String structname;  //结构体名称
}Type;

int EquType(Type* a,Type* b){
    //两个类型是否等价？
    //对于结构体直接判断名称
    //对于数组，递归判断，各个维度必须一致
    //Note：为了让大家看的明白我删去了处理附加要求的部分
    //如果你希望实现附加要求的结构体结构匹配，可以把结构体处理成唯一字符串的形式，判断同构
    /*
        For example:
        struct ywy{
            int a;
            float b;
            struct{
                int c,d;
            } e;
        };
        struct sb{
            int v;
            float w;
            struct {
                int x,y;
            } z;
        };
        它们对应的字符串（签名）可以都被处理为{int,float,{int,int}}，因此ywy与sb同构
        处理成啥样看你个人喜好，只要具有同构唯一性即可
    */
    if(a->type != b->type)
        return 0;
    if(a->type == Type_INT || a->type == Type_FLOAT)
        return 1;
    if(a->type == Type_Struct)
        return EquStr(a->structname,b->structname); //结构体直接判名相等
    if(a->size != b->size)  //维度容量不一致
        return 0;
    return EquType(a->arrbase,b->arrbase);  //递归判断
}

typedef struct{     //函数声明，作为函数表结点的值
    int argcnt;     //参数个数
    Type* ret;      //返回类型
    Type** args;    //动态分配的变长数组，各个参数的类型
    String name;    //函数名
    //Note: 这里不需要存储参数名称，因为它们只在函数定义处的CompSt有效
    //函数调用时，不会管各个参数都叫啥，只需要知道它们的类型即可
}Func;

typedef struct{     //抽象的动态数组，模仿std::vector或者其它语言中的ArrayList等
                    //这里其实也可用链表替代，看你个人喜好
                    //只需要能够实现“在结尾处追加一个对象”以及“遍历所有对象”即可
    void** ptr;     //动态数组的内存区，成员可以是任何类型对象的指针
                    //Note：C中的void*类似其它语言中的Object，可以兼容任何类型指针
    int size;       //元素个数
    int limit;      //分配空间用的
}Vector;

Vector NewVector(){ //初始化Vector
    Vector vec;
    vec.ptr=(void**)malloc(sizeof(void*));
    vec.limit=1;
    vec.size=0;
    return vec;
}

Vector PushBack(Vector vec,void* obj){
    //向Vector结尾追加一个对象
    //使用方式：vector=PushBack(vector,object)，类似这样
    if(vec.size == vec.limit){
        void** np=(void**)malloc(vec.limit * 2 * sizeof(void*));
        memcpy(np,vec.ptr,vec.limit * sizeof(void*));
        vec.limit <<= 1;
        free(vec.ptr);
        vec.ptr=np;
    }
    vec.ptr[vec.size++]=obj;
    return vec;
}

#endif